module.exports = {
  env: {
    jest: true
  },
  "parserOptions": {
    "ecmaVersion": 7,
    "sourceType": "module"
  },
  "parser": "vue-eslint-parser"
}
