/* eslint-disable no-mixed-spaces-and-tabs */
module.exports = {

  title: '鑫艺拍拍',

  /**
   * @type {boolean} true | false
   * @description Whether fix the header
   */
  fixedHeader: false,
	 // eslint-disable-next-line no-mixed-spaces-and-tabs
	 /**
   * @type {boolean} true | false
   * @description Whether need tagsView
   */
  tagsView: true,

  /**
   * @type {boolean} true | false
   * @description Whether fix the header
  /**
   * @type {boolean} true | false
   * @description Whether show the logo in sidebar
   */
  sidebarLogo: false
}
