<template>
	<div>
		<router-view></router-view>
	</div>
</template>
<script>
import components from './list/index.vue';
export default {
	name:'mallOrder',
}
</script>
