let URL = 'https://xypp.natapp4.cc'
// let URL = 'https://xypp.xinyipaipai.com'


export default URL
